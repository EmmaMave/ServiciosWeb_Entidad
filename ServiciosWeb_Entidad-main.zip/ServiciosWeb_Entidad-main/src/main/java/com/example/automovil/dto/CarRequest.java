package com.example.automovil.dto;

import jakarta.validation.constraints.NotBlank;

public record CarRequest(

    @NotBlank(message = "The brand is mandatory")
    String brand,

    @NotBlank(message = "The model is mandatory")
    String model,

    @NotBlank(message = "The color is mandatory")
    String color

   // @NotNull(message = "El año es obligatorio")
//    @Positive(message = "El año debe ser un número positivo")
//    Integer anio
) {}
